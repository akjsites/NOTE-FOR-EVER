package com.lab.blc;

public class Dog {
	String name;
	double height;
	int age;
public void getDogInformation() {
System.out.println("Dog Name     : "+name);	
System.out.println("Dog Height   : "+height);
System.out.println("Dog Age      : "+age);
}
public void bark() {
	System.out.println(name+" is barking!");
}
}
