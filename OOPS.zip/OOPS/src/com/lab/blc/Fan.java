package com.lab.blc;

public class Fan{
    String name;
    String coil;
    int wings;
    public  void sitchOn(){
        System.out.println("Fan is switched ON");
    }
    public void swithOff()
    {
 System.out.println("Fan is switched OFF");
    }
}
