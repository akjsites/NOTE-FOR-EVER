package com.kalia.passby_value;

public class Madicene {

}
