package com.kalia.passby_value;

public class MadiceneCost {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
