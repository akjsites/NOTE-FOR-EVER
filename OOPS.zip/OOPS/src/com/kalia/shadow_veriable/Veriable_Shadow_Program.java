package com.kalia.shadow_veriable;

public class Veriable_Shadow_Program {

	public static void main(String[] args) {
		VeriableShadow stu=new VeriableShadow();
		stu.accept("Btech");

	}

}
