package com.kalia.shadow_veriable;

public class ProductDemo {

	public static void main(String[] args) {
		Product pro=new Product();
		pro.setProductData(101, "Hp", 140000);
		System.out.println(pro.toString());
int [] age=new int[10];
	}

}
