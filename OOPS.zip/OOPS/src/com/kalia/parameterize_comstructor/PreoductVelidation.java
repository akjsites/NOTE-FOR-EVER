package com.kalia.parameterize_comstructor;

public class PreoductVelidation {

	public static void main(String[] args) {
	Product name=new Product(101, "kkk", -7888);
	System.out.println(name);
	}

}
