package com.kalia.parameterize_comstructor;

public class BookDetail {

	public static void main(String[] args) {
	Book kk=new Book("1984", null, -1200, 12);
	
	System.out.println(kk);

	}

}
