package com.kalia.factorymodel;

public class BookApplication {

	public static void main(String[] args) {
		Book kalia=Book.getData();
		System.out.println(kalia);
	}

}
