package com.kalia.copy_constuctor;

public class EmployeeRecord {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
