package com.kalia.copy_constuctor;

public class Employee {

}
