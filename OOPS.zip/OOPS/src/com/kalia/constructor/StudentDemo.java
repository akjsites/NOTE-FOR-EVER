package com.kalia.constructor;

public class StudentDemo {

	public static void main(String[] args) {
		Student aswini=new Student(102,"AKJ");
		
//		System.out.println(aswini);

	}

}
