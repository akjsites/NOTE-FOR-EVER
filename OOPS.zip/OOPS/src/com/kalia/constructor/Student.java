package com.kalia.constructor;

public class Student {
  
	private int roll;
	private String name;
	public Student(int roll, String name) {
		
//		this.roll = roll;
//		this.name = name;
		System.out.println(this.roll=roll);
		System.out.println(this.name=name);
	}
//	@Override
//	public String toString() {
//		return "Student [roll=" + roll + ", name=" + name + "]";
//	}
	

}
