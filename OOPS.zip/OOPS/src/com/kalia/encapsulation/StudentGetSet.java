package com.kalia.encapsulation;

public class StudentGetSet {

	public static void main(String[] args) {
		Student kalia=new Student("Kalia Gouda", 83);
		System.out.println(kalia);
		kalia.setName("Balia");
		System.out.println(kalia);
	}

}
