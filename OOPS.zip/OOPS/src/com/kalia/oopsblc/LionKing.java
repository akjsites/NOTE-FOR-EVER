package com.kalia.oopsblc;

public class LionKing {
	String color;
	public void getColor(String col) {
		color=col;
	}
   public void displayColor() {
	   System.out.println(color);
   }
   
}
