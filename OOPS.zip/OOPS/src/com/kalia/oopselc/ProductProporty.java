package com.kalia.oopselc;

import com.kalia.oopsblc.Product;

public class ProductProporty {

	public static void main(String[] args) {
		Product detail=new Product();
		detail.setData(101, "Kalia", 1200);
		detail.getProductData();

	}

}
