package com.kalia.oopselc;

public class MainProgram {

	public static void main(String[] args) {
		Student kalia=new Student();
		kalia.name="kalia Gouda";
		kalia.age=21;
		kalia.height=5.9;
		kalia.playName="cricket";
		kalia.talk();
		kalia.play();
	}

}
