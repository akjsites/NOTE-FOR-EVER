package com.kalia.oopselc;

import com.kalia.oopsblc.Dog;

public class DogProgram {

	public static void main(String[] args) {
		Dog mitu =new Dog();
		mitu.getData();
		mitu.dogDetail();
	}

}
