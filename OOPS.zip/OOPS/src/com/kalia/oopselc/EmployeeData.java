package com.kalia.oopselc;

import com.kalia.oopsblc.ReadEmployeeData;

public class EmployeeData {

	public static void main(String[] args) {
		ReadEmployeeData person=new ReadEmployeeData();
		person.getEmployeeData();
		person.employeeData();
	}

}
