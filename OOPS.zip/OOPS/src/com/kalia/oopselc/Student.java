package com.kalia.oopselc;

public class Student {
  String name;
  int age;
  double height;
   String playName; 
  public void  talk() {
	  System.out.println("hello guys my name is"+name);
	  System.out.println("my age is"+age);
	  System.out.println("my height is"+height);
	  
  }
  public void play() {
	  System.out.println("i play "+playName);
  }
}
