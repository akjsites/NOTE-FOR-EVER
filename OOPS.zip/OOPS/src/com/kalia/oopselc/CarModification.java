package com.kalia.oopselc;

import com.kalia.oopsblc.CarDesigner;

public class CarModification {

	public static void main(String[] args) {
		CarDesigner car=new CarDesigner();
		car.getCardata("tata", "black", 2, 800000);
		car.carDeatil();

	}

}
