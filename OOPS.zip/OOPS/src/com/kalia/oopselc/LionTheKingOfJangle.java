package com.kalia.oopselc;

import com.kalia.oopsblc.LionKing;

public class LionTheKingOfJangle {

	public static void main(String[] args) {
		LionKing kalia= new LionKing();
		kalia.getColor("blue");
		kalia.displayColor();
	}

}
